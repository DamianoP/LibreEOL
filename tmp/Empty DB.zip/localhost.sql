-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Creato il: Giu 22, 2019 alle 03:42
-- Versione del server: 10.1.16-MariaDB-1~trusty
-- Versione PHP: 7.0.33-0ubuntu0.16.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `EOL`
--
CREATE DATABASE IF NOT EXISTS `EOL` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `EOL`;

-- --------------------------------------------------------

--
-- Struttura della tabella `Answers`
--

CREATE TABLE `Answers` (
  `idAnswer` int(10) UNSIGNED NOT NULL COMMENT 'Answer''s ID',
  `score` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Answer''s score',
  `fkQuestion` int(10) UNSIGNED NOT NULL COMMENT 'Question''s ID',
  `fksub` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Answers respective to a question';

-- --------------------------------------------------------

--
-- Struttura della tabella `Certificates`
--

CREATE TABLE `Certificates` (
  `idCertificate` mediumint(9) NOT NULL,
  `year` int(11) NOT NULL,
  `whoGenerated` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `Exams`
--

CREATE TABLE `Exams` (
  `idExam` int(10) UNSIGNED NOT NULL COMMENT 'Exam''s ID',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Exam''s name',
  `datetime` datetime NOT NULL COMMENT 'Exam''s day and time',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Exam''s description',
  `regStart` datetime DEFAULT NULL COMMENT 'Exam''s registration start time',
  `regEnd` datetime DEFAULT NULL COMMENT 'Exam''s registration end time',
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Exam''s password',
  `status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'w' COMMENT 'Exam''s status (w -> waiting, s -> started, e -> ended, a -> archived)',
  `fkTestSetting` int(10) UNSIGNED DEFAULT NULL COMMENT 'Exam''s test setting',
  `fkSubject` int(10) UNSIGNED NOT NULL COMMENT 'Exam''s subject',
  `group` int(11) DEFAULT NULL,
  `subgroup` int(11) DEFAULT NULL,
  `idUsr` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Teacher''s Exams';

-- --------------------------------------------------------

--
-- Struttura della tabella `Exams_Rooms`
--

CREATE TABLE `Exams_Rooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `fkExam` int(10) UNSIGNED NOT NULL COMMENT 'Exam''s ID',
  `fkRoom` int(10) UNSIGNED DEFAULT NULL COMMENT 'Room''s ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Clients allowed to execute a specific exams';

-- --------------------------------------------------------

--
-- Struttura della tabella `Flag_Import`
--

CREATE TABLE `Flag_Import` (
  `done` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Flag to check if import is done';

-- --------------------------------------------------------

--
-- Struttura della tabella `GroupNTC`
--

CREATE TABLE `GroupNTC` (
  `idGroup` int(11) NOT NULL,
  `NameGroup` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `History`
--

CREATE TABLE `History` (
  `idHistory` bigint(20) UNSIGNED NOT NULL COMMENT 'History''s ID',
  `fkTest` int(10) UNSIGNED DEFAULT NULL COMMENT 'Test''s ID',
  `fkQuestion` int(10) UNSIGNED NOT NULL COMMENT 'Question''s ID',
  `answer` text COLLATE utf8_unicode_ci COMMENT 'Text of open answer question',
  `score` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Value of submitted answer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='History of all questions and submitted answers for all tests';

-- --------------------------------------------------------

--
-- Struttura della tabella `Languages`
--

CREATE TABLE `Languages` (
  `idLanguage` int(10) UNSIGNED NOT NULL COMMENT 'Language''s ID',
  `alias` char(5) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Language''s alias (e.g. en_UK)',
  `description` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Language''s description'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Availables languages';

-- --------------------------------------------------------

--
-- Struttura della tabella `Questions`
--

CREATE TABLE `Questions` (
  `idQuestion` int(10) UNSIGNED NOT NULL COMMENT 'Question''s ID',
  `type` char(5) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Question''s type',
  `difficulty` tinyint(4) UNSIGNED NOT NULL COMMENT 'Question''s difficulty',
  `status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'i' COMMENT 'Question''s status (a->active, i->inactive, e->error)',
  `extra` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'Question''s extra (c->calculator, p->periodic table, ...)',
  `shortText` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Question''s description',
  `fkRootQuestion` int(10) UNSIGNED DEFAULT '0' COMMENT 'Root question''s ID',
  `fkTopic` int(10) UNSIGNED DEFAULT NULL COMMENT 'Topic''s ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Questions relevant to a topic';

-- --------------------------------------------------------

--
-- Struttura della tabella `Questions_History`
--

CREATE TABLE `Questions_History` (
  `FkQuestion` int(10) NOT NULL COMMENT 'id of actual question',
  `FkQuestionParent` int(10) NOT NULL COMMENT 'id of original question',
  `WhoChanged` varchar(250) NOT NULL COMMENT 'who changed question',
  `Date` date NOT NULL COMMENT 'date of changement'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `Questions_TestSettings`
--

CREATE TABLE `Questions_TestSettings` (
  `fkQuestion` int(10) UNSIGNED NOT NULL COMMENT 'Question''s ID',
  `fkTestSetting` int(10) UNSIGNED NOT NULL COMMENT 'Test Setting''s ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `ReportTemplate`
--

CREATE TABLE `ReportTemplate` (
  `idTemplate` int(11) NOT NULL,
  `name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `assesmentName` int(11) NOT NULL,
  `assesmentID` int(11) NOT NULL,
  `assesmentAuthor` int(11) NOT NULL,
  `assesmentDateTimeFirst` int(11) NOT NULL,
  `assesmentDateTimeLast` int(11) NOT NULL,
  `assesmentNumberStarted` int(11) NOT NULL,
  `assesmentNumberNotFinished` int(11) NOT NULL,
  `assesmentNumberFinished` int(11) NOT NULL,
  `assesmentMinscoreFinished` int(11) NOT NULL,
  `assesmentMaxscoreFinished` int(11) NOT NULL,
  `assesmentMediumFinished` int(11) NOT NULL,
  `assesmentLeastTimeFinished` int(11) NOT NULL,
  `assesmentMostTimeFinished` int(11) NOT NULL,
  `assesmentMediumTimeFinished` int(11) NOT NULL,
  `assesmentStdDeviation` int(11) NOT NULL,
  `topicAverageScore` int(11) NOT NULL,
  `topicMinimumScore` int(11) NOT NULL,
  `topicMaximumScore` int(11) NOT NULL,
  `topicStdDeviation` int(11) NOT NULL,
  `graphicHistogram` int(11) NOT NULL,
  `graphicTopicScore` int(11) NOT NULL,
  `fkUser` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table for Report Template ';

-- --------------------------------------------------------

--
-- Struttura della tabella `Rooms`
--

CREATE TABLE `Rooms` (
  `idRoom` int(10) UNSIGNED NOT NULL COMMENT 'Room''s ID',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Room''s name',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Room''s description',
  `ipStart` int(10) UNSIGNED NOT NULL COMMENT 'Room''s clients IP start',
  `ipEnd` int(10) UNSIGNED NOT NULL COMMENT 'Room''s clients IP end'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Clients allowed to execute the exams';

-- --------------------------------------------------------

--
-- Struttura della tabella `Sets`
--

CREATE TABLE `Sets` (
  `idSet` int(10) UNSIGNED NOT NULL COMMENT 'Set''s ID',
  `assigned` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'n' COMMENT 'Check if set is assigned (y) or not (n)',
  `fkExam` int(10) UNSIGNED NOT NULL COMMENT 'Exam''s ID ',
  `fkUser` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Question sets';

-- --------------------------------------------------------

--
-- Struttura della tabella `Sets_Questions`
--

CREATE TABLE `Sets_Questions` (
  `fkSet` int(10) UNSIGNED NOT NULL COMMENT 'Set''s ID',
  `fkQuestion` int(10) UNSIGNED NOT NULL COMMENT 'Question''s ID',
  `answer` text COLLATE utf8_unicode_ci COMMENT 'ID or text for answered question in this set',
  `fkIdLanguage` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Association between Questions and test''s sets';

-- --------------------------------------------------------

--
-- Struttura della tabella `SubGroup`
--

CREATE TABLE `SubGroup` (
  `idSubGroup` int(11) NOT NULL,
  `NameSubGroup` varchar(100) NOT NULL,
  `fkGroup` int(11) NOT NULL,
  `Description` varchar(200) NOT NULL DEFAULT 'University of'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `Sub_Questions`
--

CREATE TABLE `Sub_Questions` (
  `sub_questions` int(10) NOT NULL,
  `fkQuestions` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table for Pull down Question';

-- --------------------------------------------------------

--
-- Struttura della tabella `Subjects`
--

CREATE TABLE `Subjects` (
  `idSubject` int(10) UNSIGNED NOT NULL COMMENT 'Subject''s ID',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Subject''s name',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Subject''s description',
  `fkLanguage` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Main language''s ID',
  `version` double DEFAULT '-1' COMMENT 'Subjects version'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Subjects';

-- --------------------------------------------------------

--
-- Struttura della tabella `TestSettings`
--

CREATE TABLE `TestSettings` (
  `idTestSetting` int(10) UNSIGNED NOT NULL COMMENT 'Test setting''s ID',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Test setting''s name',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Test setting''s description',
  `questions` smallint(5) UNSIGNED NOT NULL COMMENT 'Test setting''s question''s number',
  `scoreType` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Test setting''s score type',
  `scoreMin` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Test setting''s minimum score',
  `scale` double NOT NULL DEFAULT '1' COMMENT 'Test setting''s score factor scale',
  `bonus` double DEFAULT '0' COMMENT 'Test setting''s bonus',
  `duration` int(10) UNSIGNED NOT NULL COMMENT 'Test setting''s duration time in mins',
  `numEasy` int(10) NOT NULL COMMENT 'Test setting''s easy questions',
  `numMedium` int(10) NOT NULL COMMENT 'Test setting''s medium questions',
  `numHard` int(10) NOT NULL COMMENT 'Test setting''s hard questions',
  `fkSubject` int(10) UNSIGNED NOT NULL COMMENT 'Test setting''s subject',
  `negative` tinyint(1) DEFAULT '0' COMMENT 'Negative Scores',
  `editable` tinyint(1) DEFAULT '0' COMMENT 'Editable Scores',
  `certificate` int(11) NOT NULL DEFAULT '0',
  `group` int(11) DEFAULT NULL,
  `subgroup` int(11) DEFAULT NULL,
  `idUser` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Configuration setting of exam for specific subject';

-- --------------------------------------------------------

--
-- Struttura della tabella `Tests`
--

CREATE TABLE `Tests` (
  `idTest` int(10) UNSIGNED NOT NULL COMMENT 'Test''s ID',
  `timeStart` datetime DEFAULT NULL COMMENT 'Test''s start time',
  `timeEnd` datetime DEFAULT NULL COMMENT 'Test''s end time',
  `scoreTest` double DEFAULT NULL COMMENT 'Test''s score',
  `bonus` double DEFAULT '0' COMMENT 'Test''s assigned bonus',
  `scoreFinal` double DEFAULT NULL COMMENT 'Final score',
  `status` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'w' COMMENT 'Test''s status (w->waiting, s->started, e->ended, a->archived, b->blocked)',
  `fkExam` int(10) UNSIGNED DEFAULT NULL COMMENT 'Test exam''s ID',
  `fkUser` int(10) UNSIGNED DEFAULT NULL COMMENT 'Test student''s ID',
  `fkSet` int(10) UNSIGNED DEFAULT NULL COMMENT 'Test''s set'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Test performed by a student in a exact exam';

-- --------------------------------------------------------

--
-- Struttura della tabella `Tokens`
--

CREATE TABLE `Tokens` (
  `email` varchar(45) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s email',
  `action` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'c' COMMENT 'Token''s action (c->create, p->password)',
  `value` char(40) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Token''s SHA-1 value (40B length)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tokens for create account and password lost';

-- --------------------------------------------------------

--
-- Struttura della tabella `Topics`
--

CREATE TABLE `Topics` (
  `idTopic` int(10) UNSIGNED NOT NULL COMMENT 'Topic''s ID',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Topic''s name',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Topic''s description',
  `fkSubject` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Subject''s ID',
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique Code Topics Imported'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Topics respective to a subject';

-- --------------------------------------------------------

--
-- Struttura della tabella `Topics_TestSettings`
--

CREATE TABLE `Topics_TestSettings` (
  `fkTestSetting` int(10) UNSIGNED NOT NULL COMMENT 'Test Setting''s ID',
  `fkTopic` int(10) UNSIGNED NOT NULL COMMENT 'Topic''s ID',
  `numEasy` int(10) NOT NULL COMMENT 'Random easy questions',
  `numMedium` int(10) NOT NULL COMMENT 'Random medium questions',
  `numHard` int(10) NOT NULL COMMENT 'Random hard questions',
  `numQuestions` int(10) NOT NULL COMMENT 'Number of topic questions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `TranslationAnswers`
--

CREATE TABLE `TranslationAnswers` (
  `fkAnswer` int(10) UNSIGNED NOT NULL COMMENT 'Answer''s ID',
  `fkLanguage` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Language''s ID',
  `translation` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Answer''s translation text'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Answers with they''re translations';

-- --------------------------------------------------------

--
-- Struttura della tabella `TranslationQuestions`
--

CREATE TABLE `TranslationQuestions` (
  `fkQuestion` int(10) UNSIGNED NOT NULL COMMENT 'Question''s ID',
  `fkLanguage` int(10) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Language''s ID',
  `translation` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Question''s translation text'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Questions with they''re translations';

-- --------------------------------------------------------

--
-- Struttura della tabella `TranslationSubQuestion`
--

CREATE TABLE `TranslationSubQuestion` (
  `fkSubQuestion` int(10) NOT NULL,
  `fkLanguage` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `translation` text COLLATE utf8_unicode_ci NOT NULL,
  `fkQuestion` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='SubQuestions with they''re translations';

-- --------------------------------------------------------

--
-- Struttura della tabella `Users`
--

CREATE TABLE `Users` (
  `idUser` int(10) UNSIGNED NOT NULL COMMENT 'User''s ID',
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s name',
  `surname` varchar(35) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s surname',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User''s email',
  `password` char(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'User''s SHA-1 password (40B length)',
  `group` int(11) NOT NULL,
  `subgroup` int(11) NOT NULL,
  `role` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 's' COMMENT 'User''s role (a->admin, t->teacher, s->student, at->teacher and admin)',
  `fkLanguage` int(10) UNSIGNED DEFAULT '1' COMMENT 'User''s Language ID',
  `privacy` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Teachers and system admins';

-- --------------------------------------------------------

--
-- Struttura della tabella `Users_Subjects`
--

CREATE TABLE `Users_Subjects` (
  `id` int(10) UNSIGNED NOT NULL,
  `fkUser` int(10) UNSIGNED DEFAULT NULL COMMENT 'User''s ID',
  `fkSubject` int(10) UNSIGNED NOT NULL COMMENT 'Subject''s ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Relation between Teachers and Subjects';

-- --------------------------------------------------------

--
-- Struttura della tabella `questionsdistribution`
--

CREATE TABLE `questionsdistribution` (
  `fkTestSetting` int(10) UNSIGNED NOT NULL,
  `fkQuestion` int(10) UNSIGNED NOT NULL,
  `counter` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `Answers`
--
ALTER TABLE `Answers`
  ADD PRIMARY KEY (`idAnswer`),
  ADD KEY `fk_Answers_Questions_idx` (`fkQuestion`),
  ADD KEY `Answers_ibfk_1` (`fksub`);

--
-- Indici per le tabelle `Certificates`
--
ALTER TABLE `Certificates`
  ADD PRIMARY KEY (`idCertificate`);

--
-- Indici per le tabelle `Exams`
--
ALTER TABLE `Exams`
  ADD PRIMARY KEY (`idExam`),
  ADD KEY `fk_Exams_TestSetting_idx` (`fkTestSetting`),
  ADD KEY `fk_Exams_Subject_idx` (`fkSubject`);

--
-- Indici per le tabelle `Exams_Rooms`
--
ALTER TABLE `Exams_Rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Exams_Rooms_Room_idx` (`fkRoom`),
  ADD KEY `fk_Exams_Rooms_Exam_idx` (`fkExam`);

--
-- Indici per le tabelle `GroupNTC`
--
ALTER TABLE `GroupNTC`
  ADD PRIMARY KEY (`idGroup`);

--
-- Indici per le tabelle `History`
--
ALTER TABLE `History`
  ADD PRIMARY KEY (`idHistory`) KEY_BLOCK_SIZE=16,
  ADD KEY `fk_History_Test_idx` (`fkTest`),
  ADD KEY `fk_History_Question_idx` (`fkQuestion`);

--
-- Indici per le tabelle `Languages`
--
ALTER TABLE `Languages`
  ADD PRIMARY KEY (`idLanguage`),
  ADD UNIQUE KEY `alias_UNIQUE` (`alias`);

--
-- Indici per le tabelle `Questions`
--
ALTER TABLE `Questions`
  ADD PRIMARY KEY (`idQuestion`),
  ADD KEY `fk_Questions_Topics_idx` (`fkTopic`);

--
-- Indici per le tabelle `Questions_History`
--
ALTER TABLE `Questions_History`
  ADD PRIMARY KEY (`FkQuestion`);

--
-- Indici per le tabelle `Questions_TestSettings`
--
ALTER TABLE `Questions_TestSettings`
  ADD PRIMARY KEY (`fkQuestion`,`fkTestSetting`),
  ADD KEY `fk_Questions_TestSettings_TestSetting` (`fkTestSetting`);

--
-- Indici per le tabelle `ReportTemplate`
--
ALTER TABLE `ReportTemplate`
  ADD PRIMARY KEY (`idTemplate`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `fkUser` (`fkUser`);

--
-- Indici per le tabelle `Rooms`
--
ALTER TABLE `Rooms`
  ADD PRIMARY KEY (`idRoom`);

--
-- Indici per le tabelle `Sets`
--
ALTER TABLE `Sets`
  ADD PRIMARY KEY (`idSet`),
  ADD KEY `fk_Sets_Exam_idx` (`fkExam`);

--
-- Indici per le tabelle `Sets_Questions`
--
ALTER TABLE `Sets_Questions`
  ADD PRIMARY KEY (`fkSet`,`fkQuestion`),
  ADD KEY `fk_Sets_Questions_Set_idx` (`fkSet`),
  ADD KEY `fk_Sets_Questions_Question_idx` (`fkQuestion`);

--
-- Indici per le tabelle `SubGroup`
--
ALTER TABLE `SubGroup`
  ADD PRIMARY KEY (`idSubGroup`),
  ADD UNIQUE KEY `NameSubGroup` (`NameSubGroup`),
  ADD KEY `fkGroup` (`fkGroup`);

--
-- Indici per le tabelle `Sub_Questions`
--
ALTER TABLE `Sub_Questions`
  ADD PRIMARY KEY (`sub_questions`),
  ADD KEY `fkQuestions` (`fkQuestions`);

--
-- Indici per le tabelle `Subjects`
--
ALTER TABLE `Subjects`
  ADD PRIMARY KEY (`idSubject`),
  ADD UNIQUE KEY `sbjC` (`name`,`fkLanguage`,`version`),
  ADD KEY `fk_Subjects_Language_idx` (`fkLanguage`);

--
-- Indici per le tabelle `TestSettings`
--
ALTER TABLE `TestSettings`
  ADD PRIMARY KEY (`idTestSetting`),
  ADD KEY `fk_TestSettings_Subject_idx` (`fkSubject`);

--
-- Indici per le tabelle `Tests`
--
ALTER TABLE `Tests`
  ADD PRIMARY KEY (`idTest`) KEY_BLOCK_SIZE=16,
  ADD KEY `fk_Tests_Exam_idx` (`fkExam`) KEY_BLOCK_SIZE=16,
  ADD KEY `fk_Tests_Set_idx` (`fkSet`) KEY_BLOCK_SIZE=16,
  ADD KEY `fk_Tests_User_idx` (`fkUser`);

--
-- Indici per le tabelle `Tokens`
--
ALTER TABLE `Tokens`
  ADD PRIMARY KEY (`email`,`action`);

--
-- Indici per le tabelle `Topics`
--
ALTER TABLE `Topics`
  ADD PRIMARY KEY (`idTopic`),
  ADD UNIQUE KEY `TopicC` (`code`,`fkSubject`),
  ADD KEY `fk_Topics_Subjects_idx` (`fkSubject`);

--
-- Indici per le tabelle `Topics_TestSettings`
--
ALTER TABLE `Topics_TestSettings`
  ADD PRIMARY KEY (`fkTestSetting`,`fkTopic`),
  ADD KEY `fk_Topics_TestSettings_Topic` (`fkTopic`);

--
-- Indici per le tabelle `TranslationAnswers`
--
ALTER TABLE `TranslationAnswers`
  ADD PRIMARY KEY (`fkAnswer`,`fkLanguage`),
  ADD KEY `fk_TranslationAnswers_Answer_idx` (`fkAnswer`),
  ADD KEY `fk_TranslationAnswers_Language_idx` (`fkLanguage`);

--
-- Indici per le tabelle `TranslationQuestions`
--
ALTER TABLE `TranslationQuestions`
  ADD PRIMARY KEY (`fkLanguage`,`fkQuestion`),
  ADD KEY `fk_TranslationQuestions_Question_idx` (`fkQuestion`),
  ADD KEY `fk_TranslationQuestions_Language_idx` (`fkLanguage`);

--
-- Indici per le tabelle `TranslationSubQuestion`
--
ALTER TABLE `TranslationSubQuestion`
  ADD PRIMARY KEY (`fkSubQuestion`,`fkLanguage`),
  ADD KEY `fkQuestion` (`fkQuestion`);

--
-- Indici per le tabelle `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`idUser`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `subgroup` (`subgroup`),
  ADD KEY `group` (`group`),
  ADD KEY `fk_Users_Languages_idx` (`fkLanguage`);

--
-- Indici per le tabelle `Users_Subjects`
--
ALTER TABLE `Users_Subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Teachers_Subjects_Subject_idx` (`fkSubject`),
  ADD KEY `fk_Teachers_Subjects_Teacher_idx` (`fkUser`);

--
-- Indici per le tabelle `questionsdistribution`
--
ALTER TABLE `questionsdistribution`
  ADD PRIMARY KEY (`fkTestSetting`,`fkQuestion`),
  ADD KEY `fkQuestion` (`fkQuestion`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `Answers`
--
ALTER TABLE `Answers`
  MODIFY `idAnswer` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Answer''s ID';
--
-- AUTO_INCREMENT per la tabella `Certificates`
--
ALTER TABLE `Certificates`
  MODIFY `idCertificate` mediumint(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `Exams`
--
ALTER TABLE `Exams`
  MODIFY `idExam` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Exam''s ID';
--
-- AUTO_INCREMENT per la tabella `Exams_Rooms`
--
ALTER TABLE `Exams_Rooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `GroupNTC`
--
ALTER TABLE `GroupNTC`
  MODIFY `idGroup` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `History`
--
ALTER TABLE `History`
  MODIFY `idHistory` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'History''s ID';
--
-- AUTO_INCREMENT per la tabella `Languages`
--
ALTER TABLE `Languages`
  MODIFY `idLanguage` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Language''s ID';
--
-- AUTO_INCREMENT per la tabella `Questions`
--
ALTER TABLE `Questions`
  MODIFY `idQuestion` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Question''s ID';
--
-- AUTO_INCREMENT per la tabella `ReportTemplate`
--
ALTER TABLE `ReportTemplate`
  MODIFY `idTemplate` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `Rooms`
--
ALTER TABLE `Rooms`
  MODIFY `idRoom` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Room''s ID';
--
-- AUTO_INCREMENT per la tabella `Sets`
--
ALTER TABLE `Sets`
  MODIFY `idSet` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Set''s ID';
--
-- AUTO_INCREMENT per la tabella `SubGroup`
--
ALTER TABLE `SubGroup`
  MODIFY `idSubGroup` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `Sub_Questions`
--
ALTER TABLE `Sub_Questions`
  MODIFY `sub_questions` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `Subjects`
--
ALTER TABLE `Subjects`
  MODIFY `idSubject` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Subject''s ID';
--
-- AUTO_INCREMENT per la tabella `TestSettings`
--
ALTER TABLE `TestSettings`
  MODIFY `idTestSetting` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Test setting''s ID';
--
-- AUTO_INCREMENT per la tabella `Tests`
--
ALTER TABLE `Tests`
  MODIFY `idTest` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Test''s ID';
--
-- AUTO_INCREMENT per la tabella `Topics`
--
ALTER TABLE `Topics`
  MODIFY `idTopic` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Topic''s ID';
--
-- AUTO_INCREMENT per la tabella `Users`
--
ALTER TABLE `Users`
  MODIFY `idUser` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'User''s ID';
--
-- AUTO_INCREMENT per la tabella `Users_Subjects`
--
ALTER TABLE `Users_Subjects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `Answers`
--
ALTER TABLE `Answers`
  ADD CONSTRAINT `Answers_ibfk_1` FOREIGN KEY (`fksub`) REFERENCES `Sub_Questions` (`sub_questions`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Answers_Question` FOREIGN KEY (`fkQuestion`) REFERENCES `Questions` (`idQuestion`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Exams`
--
ALTER TABLE `Exams`
  ADD CONSTRAINT `fk_Exams_Subject` FOREIGN KEY (`fkSubject`) REFERENCES `Subjects` (`idSubject`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Exams_TestSetting` FOREIGN KEY (`fkTestSetting`) REFERENCES `TestSettings` (`idTestSetting`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limiti per la tabella `Exams_Rooms`
--
ALTER TABLE `Exams_Rooms`
  ADD CONSTRAINT `fk_Exams_Rooms_Exam` FOREIGN KEY (`fkExam`) REFERENCES `Exams` (`idExam`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Exams_Rooms_Room` FOREIGN KEY (`fkRoom`) REFERENCES `Rooms` (`idRoom`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limiti per la tabella `History`
--
ALTER TABLE `History`
  ADD CONSTRAINT `fk_History_Question` FOREIGN KEY (`fkQuestion`) REFERENCES `Questions` (`idQuestion`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_History_Test` FOREIGN KEY (`fkTest`) REFERENCES `Tests` (`idTest`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limiti per la tabella `Questions`
--
ALTER TABLE `Questions`
  ADD CONSTRAINT `fk_Questions_Topics` FOREIGN KEY (`fkTopic`) REFERENCES `Topics` (`idTopic`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limiti per la tabella `Questions_TestSettings`
--
ALTER TABLE `Questions_TestSettings`
  ADD CONSTRAINT `fk_Questions_TestSettings_Question` FOREIGN KEY (`fkQuestion`) REFERENCES `Questions` (`idQuestion`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Questions_TestSettings_TestSetting` FOREIGN KEY (`fkTestSetting`) REFERENCES `TestSettings` (`idTestSetting`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `ReportTemplate`
--
ALTER TABLE `ReportTemplate`
  ADD CONSTRAINT `ReportTemplate_ibfk_1` FOREIGN KEY (`fkUser`) REFERENCES `Users` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Sets`
--
ALTER TABLE `Sets`
  ADD CONSTRAINT `fk_Sets_Exam` FOREIGN KEY (`fkExam`) REFERENCES `Exams` (`idExam`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Sets_Questions`
--
ALTER TABLE `Sets_Questions`
  ADD CONSTRAINT `fk_Sets_Questions_Question` FOREIGN KEY (`fkQuestion`) REFERENCES `Questions` (`idQuestion`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Sets_Questions_Set` FOREIGN KEY (`fkSet`) REFERENCES `Sets` (`idSet`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `SubGroup`
--
ALTER TABLE `SubGroup`
  ADD CONSTRAINT `fk_group` FOREIGN KEY (`fkGroup`) REFERENCES `GroupNTC` (`idGroup`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Sub_Questions`
--
ALTER TABLE `Sub_Questions`
  ADD CONSTRAINT `fk_Question` FOREIGN KEY (`fkQuestions`) REFERENCES `Questions` (`idQuestion`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Subjects`
--
ALTER TABLE `Subjects`
  ADD CONSTRAINT `fk_Subjects_Language` FOREIGN KEY (`fkLanguage`) REFERENCES `Languages` (`idLanguage`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limiti per la tabella `TestSettings`
--
ALTER TABLE `TestSettings`
  ADD CONSTRAINT `fk_TestSettings_Subject` FOREIGN KEY (`fkSubject`) REFERENCES `Subjects` (`idSubject`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Tests`
--
ALTER TABLE `Tests`
  ADD CONSTRAINT `fk_Tests_Exam` FOREIGN KEY (`fkExam`) REFERENCES `Exams` (`idExam`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Tests_Set` FOREIGN KEY (`fkSet`) REFERENCES `Sets` (`idSet`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Tests_User` FOREIGN KEY (`fkUser`) REFERENCES `Users` (`idUser`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limiti per la tabella `Topics`
--
ALTER TABLE `Topics`
  ADD CONSTRAINT `fk_Topics_Subjects` FOREIGN KEY (`fkSubject`) REFERENCES `Subjects` (`idSubject`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Topics_TestSettings`
--
ALTER TABLE `Topics_TestSettings`
  ADD CONSTRAINT `fk_Topics_TestSettings_TestSetting` FOREIGN KEY (`fkTestSetting`) REFERENCES `TestSettings` (`idTestSetting`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Topics_TestSettings_Topic` FOREIGN KEY (`fkTopic`) REFERENCES `Topics` (`idTopic`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `TranslationAnswers`
--
ALTER TABLE `TranslationAnswers`
  ADD CONSTRAINT `fk_TranslationAnswers_Answer` FOREIGN KEY (`fkAnswer`) REFERENCES `Answers` (`idAnswer`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_TranslationAnswers_Language` FOREIGN KEY (`fkLanguage`) REFERENCES `Languages` (`idLanguage`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `TranslationQuestions`
--
ALTER TABLE `TranslationQuestions`
  ADD CONSTRAINT `fk_TranslationQuestions_Language` FOREIGN KEY (`fkLanguage`) REFERENCES `Languages` (`idLanguage`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_TranslationQuestions_Question` FOREIGN KEY (`fkQuestion`) REFERENCES `Questions` (`idQuestion`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `TranslationSubQuestion`
--
ALTER TABLE `TranslationSubQuestion`
  ADD CONSTRAINT `fkQuestion` FOREIGN KEY (`fkQuestion`) REFERENCES `Questions` (`idQuestion`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkSubQuestion` FOREIGN KEY (`fkSubQuestion`) REFERENCES `Sub_Questions` (`sub_questions`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `Users`
--
ALTER TABLE `Users`
  ADD CONSTRAINT `fk_SubGroup` FOREIGN KEY (`subgroup`) REFERENCES `SubGroup` (`idSubGroup`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Users_Languages` FOREIGN KEY (`fkLanguage`) REFERENCES `Languages` (`idLanguage`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limiti per la tabella `Users_Subjects`
--
ALTER TABLE `Users_Subjects`
  ADD CONSTRAINT `fk_Users_Subjects_Subject` FOREIGN KEY (`fkSubject`) REFERENCES `Subjects` (`idSubject`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Users_Subjects_User` FOREIGN KEY (`fkUser`) REFERENCES `Users` (`idUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `questionsdistribution`
--
ALTER TABLE `questionsdistribution`
  ADD CONSTRAINT `questionsdistribution_ibfk_1` FOREIGN KEY (`fkTestSetting`) REFERENCES `TestSettings` (`idTestSetting`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questionsdistribution_ibfk_2` FOREIGN KEY (`fkQuestion`) REFERENCES `Questions` (`idQuestion`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
